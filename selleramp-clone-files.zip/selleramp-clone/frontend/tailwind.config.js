/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: {50:'#eff6ff',100:'#dbeafe',200:'#bfdbfe',300:'#93c5fd',400:'#60a5fa',500:'#3b82f6',600:'#2563eb',700:'#1d4ed8',800:'#1e40af',900:'#1e3a8a'},
        secondary: {50:'#f8fafc',100:'#f1f5f9',200:'#e2e8f0',300:'#cbd5e1',400:'#94a3b8',500:'#64748b',600:'#475569',700:'#334155',800:'#1e293b',900:'#0f172a'}
      },
      animation: {'fade-in':'fadeIn .4s ease-out','slide-down':'slideDown .25s ease-out','scale-in':'scaleIn .2s ease-out'},
      keyframes: { fadeIn:{'0%':{opacity:'0'},'100%':{opacity:'1'}}, slideDown:{'0%':{opacity:'0',transform:'translateY(-8px)'},'100%':{opacity:'1',transform:'translateY(0)'}}, scaleIn:{'0%':{opacity:'0',transform:'scale(.96)'},'100%':{opacity:'1',transform:'scale(1)'}} }
    }
  },
  plugins: [],
}
