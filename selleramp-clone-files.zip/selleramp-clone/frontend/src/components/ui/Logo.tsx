import { Link } from 'react-router-dom';
import { SearchCode } from 'lucide-react';
interface LogoProps { variant?: 'dark' | 'light'; size?: 'sm' | 'md'; linkTo?: string; }
export default function Logo({ variant = 'dark', size = 'md', linkTo = '/' }: LogoProps) {
  const textClass = variant === 'light' ? 'text-white' : 'text-secondary-900';
  const iconWrap = size === 'sm' ? 'h-9 w-9' : 'h-10 w-10';
  const textSize = size === 'sm' ? 'text-lg' : 'text-xl';
  return <Link to={linkTo} className="inline-flex items-center gap-3"><div className={`flex ${iconWrap} items-center justify-center rounded-xl bg-primary-600 text-white`}><SearchCode size={20} /></div><div><div className={`font-bold ${textSize} leading-none ${textClass}`}>SellerAmp</div><div className={`text-xs ${variant === 'light' ? 'text-secondary-300' : 'text-secondary-500'}`}>SAS clone</div></div></Link>;
}
