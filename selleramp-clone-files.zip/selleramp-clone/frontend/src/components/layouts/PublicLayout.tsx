import { Outlet } from 'react-router-dom';
import Navbar from '../navigation/Navbar';
import Footer from '../navigation/Footer';
export default function PublicLayout() { return <div className="min-h-screen bg-white"><Navbar /><Outlet /><Footer /></div>; }
