import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { ArrowRight, Menu, X } from 'lucide-react';
import clsx from 'clsx';
import Logo from '../ui/Logo';
import { useAuthStore } from '../../stores/authStore';
const links = [{ label: 'Features', path: '/features' }, { label: 'Pricing', path: '/pricing' }];
export default function Navbar() {
  const [open, setOpen] = useState(false);
  const { isAuthenticated } = useAuthStore();
  return <header className="sticky top-0 z-40 border-b border-secondary-200 bg-white/80 backdrop-blur"><div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8"><Logo /><nav className="hidden items-center gap-8 md:flex">{links.map((link) => <NavLink key={link.path} to={link.path} className={({ isActive }) => clsx('text-sm font-medium transition', isActive ? 'text-primary-600' : 'text-secondary-600 hover:text-secondary-900')}>{link.label}</NavLink>)}</nav><div className="hidden items-center gap-3 md:flex">{isAuthenticated ? <Link to="/dashboard" className="btn-primary text-sm">Dashboard <ArrowRight size={16} className="ml-2" /></Link> : <><Link to="/login" className="btn-outline text-sm">Sign In</Link><Link to="/register" className="btn-primary text-sm">Start Free Trial <ArrowRight size={16} className="ml-2" /></Link></>}</div><button className="rounded-lg p-2 md:hidden" onClick={() => setOpen((v) => !v)}>{open ? <X size={22} /> : <Menu size={22} />}</button></div>{open && <div className="animate-slide-down border-t border-secondary-200 bg-white px-4 py-4 md:hidden"><div className="flex flex-col gap-2">{links.map((link) => <NavLink key={link.path} to={link.path} className="rounded-lg px-4 py-2 text-sm font-medium text-secondary-700 hover:bg-secondary-50" onClick={() => setOpen(false)}>{link.label}</NavLink>)}<div className="mt-2 flex flex-col gap-2"><Link to={isAuthenticated ? '/dashboard' : '/login'} className="btn-outline text-sm" onClick={() => setOpen(false)}>{isAuthenticated ? 'Dashboard' : 'Sign In'}</Link>{!isAuthenticated && <Link to="/register" className="btn-primary text-sm" onClick={() => setOpen(false)}>Start Free Trial</Link>}</div></div></div>}</header>;
}
