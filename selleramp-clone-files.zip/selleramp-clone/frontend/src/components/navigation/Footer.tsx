import { Link } from 'react-router-dom';
import Logo from '../ui/Logo';
const footerLinks = { Product: [{ label: 'Features', path: '/features' }, { label: 'Pricing', path: '/pricing' }], Company: [{ label: 'About', path: '#' }, { label: 'Contact', path: '#' }], Legal: [{ label: 'Privacy Policy', path: '#' }, { label: 'Terms of Service', path: '#' }] };
export default function Footer() {
  return <footer className="bg-secondary-900 text-secondary-300"><div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8"><div className="grid grid-cols-2 gap-8 md:grid-cols-5"><div className="col-span-2"><Logo variant="light" size="sm" /><p className="mt-4 max-w-sm text-sm text-secondary-400">Amazon product research, FBA profitability analysis, and sourcing workflows in one clean dashboard.</p></div>{Object.entries(footerLinks).map(([group, items]) => <div key={group}><h3 className="mb-4 text-sm font-semibold text-white">{group}</h3><ul className="space-y-3">{items.map((item) => <li key={item.label}><Link to={item.path} className="text-sm text-secondary-400 transition hover:text-white">{item.label}</Link></li>)}</ul></div>)}</div></div></footer>;
}
