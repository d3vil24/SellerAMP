import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuthStore } from './stores/authStore';
import PublicLayout from './components/layouts/PublicLayout';
import DashboardLayout from './components/layouts/DashboardLayout';
import HomePage from './pages/HomePage';
import PricingPage from './pages/PricingPage';
import FeaturesPage from './pages/FeaturesPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ForgotPasswordPage from './pages/ForgotPasswordPage';
import DashboardPage from './pages/dashboard/DashboardPage';
import SearchPage from './pages/dashboard/SearchPage';
import ProductDetailPage from './pages/dashboard/ProductDetailPage';
import CalculatorPage from './pages/dashboard/CalculatorPage';
import ListsPage from './pages/dashboard/ListsPage';
import ListDetailPage from './pages/dashboard/ListDetailPage';
import SavedProductsPage from './pages/dashboard/SavedProductsPage';
import SettingsPage from './pages/dashboard/SettingsPage';
function ProtectedRoute({ children }: { children: React.ReactNode }) { const { isAuthenticated } = useAuthStore(); if (!isAuthenticated) return <Navigate to="/login" replace />; return <>{children}</>; }
function PublicOnlyRoute({ children }: { children: React.ReactNode }) { const { isAuthenticated } = useAuthStore(); if (isAuthenticated) return <Navigate to="/dashboard" replace />; return <>{children}</>; }
export default function App() { return <Routes><Route element={<PublicLayout />}><Route path="/" element={<HomePage />} /><Route path="/pricing" element={<PricingPage />} /><Route path="/features" element={<FeaturesPage />} /></Route><Route path="/login" element={<PublicOnlyRoute><LoginPage /></PublicOnlyRoute>} /><Route path="/register" element={<PublicOnlyRoute><RegisterPage /></PublicOnlyRoute>} /><Route path="/forgot-password" element={<ForgotPasswordPage />} /><Route element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}><Route path="/dashboard" element={<DashboardPage />} /><Route path="/dashboard/search" element={<SearchPage />} /><Route path="/dashboard/product/:id" element={<ProductDetailPage />} /><Route path="/dashboard/calculator" element={<CalculatorPage />} /><Route path="/dashboard/lists" element={<ListsPage />} /><Route path="/dashboard/lists/:id" element={<ListDetailPage />} /><Route path="/dashboard/saved" element={<SavedProductsPage />} /><Route path="/dashboard/settings" element={<SettingsPage />} /></Route><Route path="*" element={<Navigate to="/" replace />} /></Routes>; }
